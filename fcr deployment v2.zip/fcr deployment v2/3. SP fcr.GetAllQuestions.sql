USE [K2UAT_Apps_IOM]
GO

/****** Object:  StoredProcedure [fcr].[GetAllQuestions]    Script Date: 15/04/2025 12:35:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


  CREATE PROCEDURE [fcr].[GetAllQuestions]
AS
BEGIN
    SELECT 
        MAX(CASE WHEN [LabelID] = 'Q1' THEN [Label] END) AS Entities,
        MAX(CASE WHEN [LabelID] = 'Q2' THEN [Label] END) AS Ultimate,
        MAX(CASE WHEN [LabelID] = 'Q3' THEN [Label] END) AS ServicesProvided,
        MAX(CASE WHEN [LabelID] = 'Q4' THEN [Label] END) AS statDetailsFeesPayable,
        MAX(CASE WHEN [LabelID] = 'Q5' THEN [Label] END) AS ProvideDetails,
        MAX(CASE WHEN [LabelID] = 'Q6' THEN [Label] END) AS anyStructChanges,
        MAX(CASE WHEN [LabelID] = 'Q7' THEN [Label] END) AS structProvideDetails,
        MAX(CASE WHEN [LabelID] = 'Q8' THEN [Label] END) AS DetailsAdverseMediaCheck,
        MAX(CASE WHEN [LabelID] = 'Q9' THEN [Label] END) AS TransactionType,
        MAX(CASE WHEN [LabelID] = 'Q10' THEN [Label] END) AS Currency,
        MAX(CASE WHEN [LabelID] = 'Q11' THEN [Label] END) AS Amount,
        MAX(CASE WHEN [LabelID] = 'Q12' THEN [Label] END) AS AdditionalInfoRelevant,
        MAX(CASE WHEN [LabelID] = 'Q13' THEN [Label] END) AS AdditionalInfoRelevantDetails,
        MAX(CASE WHEN [LabelID] = 'Q14' THEN [Label] END) AS statPleaseEnsureCopyInvoices,
        MAX(CASE WHEN [LabelID] = 'Q15' THEN [Label] END) AS Manager,
        MAX(CASE WHEN [LabelID] = 'Q16' THEN [Label] END) AS DateApproved,
        MAX(CASE WHEN [LabelID] = 'Q17' THEN [Label] END) AS Comments,
        MAX(CASE WHEN [LabelID] = 'Q18' THEN [Label] END) AS [Status],
        MAX(CASE WHEN [LabelID] = 'Q19' THEN [Label] END) AS ReferralReference
    FROM fcr.[Admin.Labels]
    WHERE [LabelID] IN ('Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7', 'Q8', 'Q9', 'Q10', 
                      'Q11', 'Q12', 'Q13', 'Q14', 'Q15', 'Q16', 'Q17', 'Q18', 'Q19', 
                      'Q20', 'Q21', 'Q22', 'Q23', 'Q24')
END
GO

