INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q6', 'Have there been any changes to the structure or services provided since the last transaction?', 'main', 'clientDetails', 6, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q7', 'If yes, provide full details ', 'main', 'clientDetails', 7, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q8', 'Details of any adverse media check Details', 'main', 'clientDetails', 8, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q9', 'Transaction Type', 'main', 'transactionDetails', 9, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q10', 'Currency', 'main', 'transactionDetails', 10, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q11', 'Amount', 'main', 'transactionDetails', 11, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q12', 'Is There Any Additional Information Relevant to the referral?', 'main', 'transactionDetails', 12, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q13', 'If yes, provide full details', 'main', 'transactionDetails', 13, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q14', 'Please ensure that all copy invoices and/or any other supporting documents are attached to the request prior to submission', 'main', 'transactionDetails', 14, 'statement', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q15', 'Manager', 'main', 'managerApproval', 15, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q16', 'Date Approved', 'main', 'managerApproval', 16, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q17', 'Comments', 'main', 'managerApproval', 17, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q18', 'Status', 'main', 'managerApproval', 18, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');

INSERT INTO [fcr].[Admin.Labels] ([LabelID], [Label], [TabName], [ViewName], [Order], [Type], [GuidanceNotes], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]) 
VALUES 
('Q19', 'Referral Reference', 'main', 'managerApproval', 19, 'control', NULL, GETDATE(), 'Kaua Dorneles (Okta)', GETDATE(), 'Kaua Dorneles (Okta)');
