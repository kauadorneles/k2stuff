USE [K2UAT_Apps_IOM]
GO

/****** Object:  Table [fcr].[Admin.Labels]    Script Date: 15/04/2025 12:32:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [fcr].[Admin.Labels](
	[Id] [uniqueidentifier] NOT NULL,
	[LabelID] [nvarchar](50) NULL,
	[Label] [nvarchar](2000) NOT NULL,
	[TabName] [nvarchar](500) NOT NULL,
	[ViewName] [nvarchar](500) NOT NULL,
	[Order] [int] NOT NULL,
	[Type] [nvarchar](500) NOT NULL,
	[GuidanceNotes] [nvarchar](max) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](255) NOT NULL,
	[ModifiedOn] [datetime] NULL,
	[ModifiedBy] [nvarchar](255) NULL,
 CONSTRAINT [PK__Admin.La__3214EC06E61213DB] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [fcr].[Admin.Labels] ADD  CONSTRAINT [DF__Admin.Labels__Id__2EA5EC27]  DEFAULT (newid()) FOR [Id]
GO

