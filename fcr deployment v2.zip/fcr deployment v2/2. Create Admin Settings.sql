USE [K2UAT_Apps_IOM]
GO

/****** Object:  Table [fcr].[Admin.Settings]    Script Date: 15/04/2025 12:34:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [fcr].[Admin.Settings](
	[Id] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](2000) NOT NULL,
	[Value] [nvarchar](max) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK__Admin.Settings] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [fcr].[Admin.Settings] ADD  DEFAULT (newid()) FOR [Id]
GO

