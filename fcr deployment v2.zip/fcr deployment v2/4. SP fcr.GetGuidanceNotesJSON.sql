USE [K2UAT_Apps_IOM]
GO

/****** Object:  StoredProcedure [fcr].[GetGuidanceNotesJSON]    Script Date: 15/04/2025 12:36:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [fcr].[GetGuidanceNotesJSON]
(
	@pTabName nvarchar(255)
 )
as
begin

declare @JSONreturn nvarchar(max);
set @JSONreturn = (

select 
		[TabName],
		[ViewName] ,
		[Order],
		[Type],
		[GuidanceNotes]	
	from fcr.[Admin.Labels] where GuidanceNotes is not null-- and TabName = @pTabName
	FOR JSON AUTO)

	select @JSONreturn as JSONreturn

end
GO

